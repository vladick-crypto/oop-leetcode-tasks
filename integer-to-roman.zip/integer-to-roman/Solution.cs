// Рішення для LeetCode: integer-to-roman
public class Solution { /* Код засабмічено на сайті */ }
