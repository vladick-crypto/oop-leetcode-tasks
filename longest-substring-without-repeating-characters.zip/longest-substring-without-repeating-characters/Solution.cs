// Рішення для LeetCode: longest-substring-without-repeating-characters
public class Solution { /* Код засабмічено на сайті */ }
