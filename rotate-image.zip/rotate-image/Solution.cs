// Рішення для LeetCode: rotate-image
public class Solution { /* Код засабмічено на сайті */ }
