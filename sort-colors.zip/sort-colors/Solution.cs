// Рішення для LeetCode: sort-colors
public class Solution { /* Код засабмічено на сайті */ }
