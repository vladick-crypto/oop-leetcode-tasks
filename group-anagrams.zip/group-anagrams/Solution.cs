// Рішення для LeetCode: group-anagrams
public class Solution { /* Код засабмічено на сайті */ }
