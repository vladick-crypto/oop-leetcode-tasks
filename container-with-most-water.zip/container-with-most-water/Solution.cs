// Рішення для LeetCode: container-with-most-water
public class Solution { /* Код засабмічено на сайті */ }
