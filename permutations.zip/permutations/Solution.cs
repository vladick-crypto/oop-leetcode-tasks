// Рішення для LeetCode: permutations
public class Solution { /* Код засабмічено на сайті */ }
