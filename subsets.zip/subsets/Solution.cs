// Рішення для LeetCode: subsets
public class Solution { /* Код засабмічено на сайті */ }
