// Рішення для LeetCode: generate-parentheses
public class Solution { /* Код засабмічено на сайті */ }
